import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    menus: ['피자','치킨','짜장면','짬뽕','순대국밥','파스타','냉면','콩국수','금식','백반']
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
